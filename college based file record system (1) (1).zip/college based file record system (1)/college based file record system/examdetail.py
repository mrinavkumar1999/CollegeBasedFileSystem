from tkinter import*
from tkinter import ttk,messagebox
import os
import Panel

class Examdetail:
    def __init__(self):
        self.root=Tk()
        self.root.title("College Based File Record System")
        self.root.geometry("1540x790+0+0")


        title=Label(self.root,text="EXAM RECORD",font=("times new roman",40,"bold"),bd=7,bg="skyblue",fg="black",relief=GROOVE)
        title.place(x=0,y=0,relwidth=1)

        exam_Frame=Frame(self.root,bd=7,relief=GROOVE)
        exam_Frame.place(x=10,y=85,width=1068,height=550)

        exam_title=Label(exam_Frame,text="Exam detail",font=("times new roman",30,"bold"))
        exam_title.place(x=350,y=5)

        #*******All Variable***********

        self.student_name=StringVar()
        self.student_id=StringVar()
        self.roll_no=StringVar()
        self.subject=StringVar()
        self.date=StringVar()
        self.marks_obtained=StringVar()
        self.total_marks=StringVar()
        self.percentage=StringVar()
        


        exam_name=Label(exam_Frame,text="Student Name",font=("times new roman",25,"bold"))
        exam_name.place(x=15,y=80)

        exam_name=Entry(exam_Frame,bd=7,textvariable=self.student_name,relief=GROOVE,width=15,font=("Arial",20))
        exam_name.place(x=230,y=80)


        exam_id=Label(exam_Frame,text="Student ID",font=("times new roman",25,"bold"))
        exam_id.place(x=15,y=190)

        exam_id=Entry(exam_Frame,textvariable=self.student_id,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        exam_id.place(x=230,y=190)

        exam_roll=Label(exam_Frame,text="Roll No",font=("times new roman",25,"bold"))
        exam_roll.place(x=15,y=294)


        txt_roll=Entry(exam_Frame,bd=7,textvariable=self.roll_no,relief=GROOVE,width=15,font=("Arial",20))
        txt_roll.place(x=230,y=294)

        exam_obt=Label(exam_Frame,text="Date(dd/mm/yyyy)",font=("times new roman",25,"bold"))
        exam_obt.place(x=510,y=80)

        exam_obt=Entry(exam_Frame,bd=7,textvariable=self.date,relief=GROOVE,width=15,font=("Arial",20))
        exam_obt.place(x=787,y=80)


        exam_sub=Label(exam_Frame,text="Subject",font=("times new roman",25,"bold"))
        exam_sub.place(x=15,y=410)

        txt_sub=Entry(exam_Frame,bd=7,textvariable=self.subject,relief=GROOVE,width=15,font=("Arial",20))
        txt_sub.place(x=230,y=410)


        exam_obt=Label(exam_Frame,text="Marks Obtained",font=("times new roman",25,"bold"))
        exam_obt.place(x=510,y=190)


        txt_obt=Entry(exam_Frame,bd=7,textvariable=self.marks_obtained,relief=GROOVE,width=15,font=("Arial",20))
        txt_obt.place(x=787,y=190)


        exam_tot=Label(exam_Frame,text="Total Marks",font=("times new roman",25,"bold"))
        exam_tot.place(x=510,y=294)

        txt_tot=Entry(exam_Frame,bd=7,textvariable=self.total_marks,relief=GROOVE,width=15,font=("Arial",20))
        txt_tot.place(x=787,y=294)

        exam_per=Label(exam_Frame,text="Percentage",font=("times new roman",25,"bold"))
        exam_per.place(x=510,y=410)

        txt_per=Entry(exam_Frame,bd=7,textvariable=self.percentage,relief=GROOVE,width=15,font=("Arial",20))
        txt_per.place(x=787,y=410)

        btn_Frame=Label(self.root,bd=7,relief=GROOVE)
        btn_Frame.place(x=10,y=665,width=1525,height=125)

        btn_save=Button(btn_Frame,text="Save",command=self.save_data,font=("Arial",27,"bold"),bd=6,width=8)
        btn_save.place(x=40,y=10)

        btn_del=Button(btn_Frame,text="Delete",command=self.delete,font=("Arial",27,"bold"),bd=6,width=8)
        btn_del.place(x=440,y=10)


        btn_cl=Button(btn_Frame,text="Clear",command=self.clear,font=("Arial",27,"bold"),bd=6,width=8)
        btn_cl.place(x=850,y=10)

        btn_exit=Button(btn_Frame,text="Exit",command=self.exit,font=("Arial",27,"bold"),bd=6,width=8)
        btn_exit.place(x=1270,y=10)

        file_Frame=Frame(self.root,bd=7,relief=GROOVE)
        file_Frame.place(x=1100,y=85,width=420,height=550)

        ftitle=Label(file_Frame,text="All files",font=("Aial",27,"bold"),bd=6,relief=GROOVE)
        ftitle.place(x=5,y=5,width=397,height=50)

        scroll_y=Scrollbar(file_Frame,orient=VERTICAL)
        self.file_list=Listbox(file_Frame,yscrollcommand=scroll_y.set)
        scroll_y.place(x=366,y=60,width=30,height=470)
        scroll_y.config(command=self.file_list.yview)
        self.file_list.place(x=3,y=54,width=359,height=479)
        self.file_list.bind("<ButtonRelease-1>",self.get_data)
        self.show_files2()

    def save_data(self):
        if self.student_name.get()=="":
            messagebox.showerror("Error","Student name must be required..")
        else:
            f=open("files2/"+str(self.student_name.get())+".txt","w")
            f.write(
                    str(self.student_name.get())+","+
                    str(self.student_id.get())+","+
                    str(self.roll_no.get())+","+
                    str(self.subject.get())+","+
                    str(self.date.get())+","+
                    str(self.marks_obtained.get())+","+
                    str(self.total_marks.get())+","+
                    str(self.percentage.get())
                    )
            f.close()
            messagebox.showinfo("Success","Record has been saved..")
            self.show_files2()


    def show_files2(self):
        files2=os.listdir("files2/")
        self.file_list.delete(0,END)
        if len(files2)>0:
            
            for i in files2:
                self.file_list.insert(END,i)


    def get_data(self,ev):
        get_cursor=self.file_list.curselection()
        #print(self.file_list.get(get_cursor))
        f1=open("files2/"+self.file_list.get(get_cursor))
        value=[]
        for f in f1:
            value=f.split(",")


        self.student_name.set(value[0])
        self.student_id.set(value[1])
        self.roll_no.set(value[2])
        self.subject.set(value[3])
        self.date.set(value[4])
        self.marks_obtained.set(value[5])
        self.total_marks.set(value[6])
        self.percentage.set(value[7])





    def clear(self):
        self.student_name.set("")
        self.student_id.set("")
        self.roll_no.set("")
        self.subject.set("")
        self.date.set("")
        self.marks_obtained.set("")
        self.total_marks.set("")
        self.percentage.set("")




    def delete(self):
        present="no"
        if self.student_name.get()=="":
            messagebox.showerror("Error","student_name mus be requied..")

        else:
            f=os.listdir("files2/")
            if len(f)>0:
                for i in f:
                    if i.split(".")[0]==self.student_name.get():
                        present="yes"



                if present=="yes":
                    ask=messagebox.askyesno("Delete","Do you really want to delete..")
                    if ask>0:
                        os.remove("files2/"+self.student_name.get()+".txt")
                        messagebox.showinfo("Success","Delete successfully")
                        self.show_files2()


                else:
                    messagebox.showerror("error","file not found")



    def exit(self):
        ask=messagebox.askyesno("exit","Do you really want to exit..")
        if ask>0:
            self.root.destroy()
            Panel.panel()
                    
