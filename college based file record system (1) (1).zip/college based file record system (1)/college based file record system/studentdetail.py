from tkinter import *
from tkinter import ttk,messagebox
import os
import time
import Panel

class Studentdetail:
    def __init__(self):
        self.root=Tk()
        self.root.title("College Based File Record System")
        self.root.geometry("1540x790+0+0")
        
        title=Label(self.root,text="STUDENT RECORD",font=("times new roman",40,"bold"),bd=7,bg=("skyblue"),fg=("black"),relief=GROOVE)
        title.place(x=0,y=0,relwidth=1)
        
        stu_Frame=Frame(self.root,bd=7,relief=GROOVE)
        stu_Frame.place(x=10,y=85,width=1068,height=550)
        
        stu_title=Label(stu_Frame,text="Student Details",font=("times new roman",30,"bold"))
        stu_title.place(x=350,y=5)
        #***********All Variables************
        self.s_id=StringVar()
        self.name=StringVar()
        self.course=StringVar()
        self.address=StringVar()
        self.city=StringVar()
        self.contact=StringVar()
        self.date=StringVar()
        self.degree=StringVar()
        self.proof=StringVar()
        self.payment=StringVar()
        

        stu_id=Label(stu_Frame,text="Student ID",font=("times new roman",25,"bold"))
        stu_id.place(x=15,y=80)

        txt_id=Entry(stu_Frame,bd=7,textvariable=self.s_id,relief=GROOVE,width=15,font=("Arial",20))
        txt_id.place(x=200,y=80)

        stu_name=Label(stu_Frame,text="Name",font=("times new roman",25,"bold"))
        stu_name.place(x=15,y=170)

        txt_name=Entry(stu_Frame,bd=7,textvariable=self.name,relief=GROOVE,width=15,font=("Arial",20))
        txt_name.place(x=200,y=170)

        stu_course=Label(stu_Frame,text="Course",font=("times new roman",25,"bold"))
        stu_course.place(x=15,y=254)

        txt_course=Entry(stu_Frame,bd=7,textvariable=self.course,relief=GROOVE,width=15,font=("Arial",20))
        txt_course.place(x=200,y=254)

        stu_address=Label(stu_Frame,text="Address",font=("times new roman",25,"bold"))
        stu_address.place(x=15,y=343)

        txt_address=Entry(stu_Frame,bd=7,textvariable=self.address,relief=GROOVE,width=15,font=("Arial",20))
        txt_address.place(x=200,y=343)

        stu_city=Label(stu_Frame,text="City",font=("times new roman",25,"bold"))
        stu_city.place(x=15,y=440)

        txt_city=Entry(stu_Frame,bd=7,textvariable=self.city,relief=GROOVE,width=15,font=("arial",20))
        txt_city.place(x=200,y=440)

        stu_con=Label(stu_Frame,text="Contact No.",font=("times new roman",25,"bold"))
        stu_con.place(x=500,y=80)

        txt_con=Entry(stu_Frame,bd=7,textvariable=self.contact,relief=GROOVE,width=15,font=("Arial",20))
        txt_con.place(x=780,y=80)

        stu_date=Label(stu_Frame,text="Date(dd/mm/yyyy)",font=("times new roman",25,"bold"))
        stu_date.place(x=500,y=170)

        txt_date=Entry(stu_Frame,bd=7,textvariable=self.date,relief=GROOVE,width=15,font=("Arial",20))
        txt_date.place(x=780,y=170)

        stu_seldeg=Label(stu_Frame,text="Select Degree",font=("times new roman",25,"bold"))
        stu_seldeg.place(x=500,y=254)
        degcombo=ttk.Combobox(stu_Frame,width=14,textvariable=self.degree,font=("Arial",20),state="readonly")
        degcombo['values']=("BCA","MCA","Btech","MBA")
        degcombo.place(x=780,y=254)

        stu_ip=Label(stu_Frame,text="ID  Proof",font=("times new roman",25,"bold"))
        stu_ip.place(x=500,y=343)

        ipcombo=ttk.Combobox(stu_Frame,width=14,textvariable=self.proof,font=("Arial",20),state="readonly")
        ipcombo['values']=("PAN Card","Adhaar Card","Student ID Card")
        ipcombo.place(x=780,y=343)

        stu_pay=Label(stu_Frame,text="Payment Mode",font=("times new roman",25,"bold"))
        stu_pay.place(x=500,y=440)

        paycombo=ttk.Combobox(stu_Frame,width=14,textvariable=self.payment,font=("Arial",20),state="readonly")
        paycombo['values']=("Cash","Internet Banking","Credit Card")
        paycombo.place(x=780,y=440)


        btn_Frame=Frame(self.root,bd=10,relief=GROOVE)
        btn_Frame.place(x=10,y=655,width=1525,height=125)

        btn_save=Button(btn_Frame,text="Save",font=("Arial",27,"bold"),command=self.save_data,bd=6,width=8)
        btn_save.place(x=40,y=10)

        btn_del=Button(btn_Frame,text="Delete",command=self.delete,font=("Arial",27,"bold"),bd=6,width=8)
        btn_del.place(x=440,y=10)

        btn_cl=Button(btn_Frame,text="Clear",command=self.clear,font=("Arial",27,"bold"),bd=6,width=8)
        btn_cl.place(x=850,y=10)

        

        btn_exit=Button(btn_Frame,text="Exit",command=self.exit,font=("Arial",27,"bold"),bd=6,width=8)
        btn_exit.place(x=1270,y=10)

        file_Frame=Frame(self.root,bd=7,relief=GROOVE)
        file_Frame.place(x=1100,y=85,width=420,height=550)

        ftitle=Label(file_Frame,text="All files",font=("Arial",20,"bold"),bd=6,relief=GROOVE)
        ftitle.place(x=5,y=5,width=397,height=50)

        scroll_y=Scrollbar(file_Frame,orient=VERTICAL)
        self.file_list=Listbox(file_Frame,yscrollcommand=scroll_y.set)
        scroll_y.place(x=366,y=60,width=30,height=470)
        scroll_y.config(command=self.file_list.yview)
        self.file_list.place(x=3,y=54,width=359,height=479)
        self.file_list.bind("<ButtonRelease-1>",self.get_data)
        self.show_files()
        
    def save_data(self):
        if self.s_id.get()=="":
            messagebox.showerror("Error","student id must be required")
        else:
            f=open("files/"+str(self.s_id.get())+".txt","w")
            f.write(
                    str(self.s_id.get())+","+
                    str(self.name.get())+","+
                    str(self.course.get())+","+
                    str(self.address.get())+","+
                    str(self.city.get())+","+
                    str(self.contact.get())+","+
                    str(self.date.get())+","+
                    str(self.degree.get())+","+
                    str(self.proof.get())+","+
                    str(self.payment.get())
                    )
            f.close()
            messagebox.showinfo("Sucess","Record has been saved..")
            self.show_files()
            
    def show_files(self):
        files=os.listdir("files/")
        self.file_list.delete(0,END)
        if len(files)>0:
            for i in files:
                self.file_list.insert(END,i)

    def get_data(self,ev):
        get_cursor=self.file_list.curselection()
        #print(self.file_list.get(get_cursor))
        f1=open("files/"+self.file_list.get(get_cursor))
        value=[]
        for f in f1:
            value=f.split(",")


        self.s_id.set(value[0])
        self.name.set(value[1])
        self.course.set(value[2])
        self.address.set(value[3])
        self.city.set(value[4])
        self.contact.set(value[5])
        self.date.set(value[6])
        self.degree.set(value[7])
        self.proof.set(value[8])
        self.payment.set(value[9])

    def clear(self):
        self.s_id.set("")
        self.name.set("")
        self.course.set("")
        self.address.set("")
        self.city.set("")
        self.contact.set("")
        self.date.set("")
        self.degree.set("")
        self.proof.set("")
        self.payment.set("")


    def delete(self):
        present="no"
        if self.s_id.get()=="":
            messagebox.showerror("Error","Student Id must be Required..")
        else:
            f=os.listdir("files/")
            if len(f)>0:
                for i in f:
                    if i.split(".")[0]==self.s_id.get():
                        present="yes"
                if present=="yes":
                    ask=messagebox.askyesno("Delete","Do you really want to delete..")
                    if ask>0:
                        os.remove("files/"+self.s_id.get()+".txt")
                        messagebox.showinfo("Sucess","Deleted Successfully")
                        self.show_files()
                else:
                    messagebox.showerror("error","file not found")


    def exit(self):
        ask=messagebox.askyesno("exit","Do you really want to exit")
        if ask>0:
            self.root.destroy()
            Panel.panel()
            
