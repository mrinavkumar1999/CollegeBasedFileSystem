from tkinter import *
from tkinter import ttk,messagebox
import os
import Panel

class Staffdetail:
    def __init__(self):
        self.root=Tk()
        self.root.title("College Based File Record System")
        self.root.geometry("1540x790+0+0")
        
        title=Label(self.root,text="STAFF RECORD",font=("times new roman",40,"bold"),bd=7,bg="skyblue",fg="black",relief=GROOVE)
        title.place(x=0,y=0,relwidth=1)
        
        staff_Frame=Frame(self.root,bd=7,relief=GROOVE)
        staff_Frame.place(x=10,y=85,width=1068,height=550)

        staff_title=Label(staff_Frame,text="Staff detail",font=("times new roman",30,"bold"))
        staff_title.place(x=350,y=5)

        
        #*****All Vriables**********
        self.first_name=StringVar()
        self.qualification=StringVar()
        self.subject=StringVar()
        self.salary=StringVar()
        self.last_name=StringVar()
        self.contact=StringVar()
        self.gender=StringVar()
        self.course=StringVar()
        
        staff_first=Label(staff_Frame,text="First Name",font=("times new roman",25,"bold"))
        staff_first.place(x=15,y=80)

        txt_first=Entry(staff_Frame,textvariable=self.first_name,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_first.place(x=230,y=80)

        staff_qua=Label(staff_Frame,text="Qualification",font=("times new roman",25,"bold"))
        staff_qua.place(x=15,y=190)

        txt_qua=Entry(staff_Frame,bd=7,textvariable=self.qualification,relief=GROOVE,width=15,font=("Arial",20))
        txt_qua.place(x=230,y=190)

        staff_sub=Label(staff_Frame,text="Subject",font=("times new roman",25,"bold"))
        staff_sub.place(x=15,y=294)

        txt_sub=Entry(staff_Frame,bd=7,textvariable=self.subject,relief=GROOVE,width=15,font=("Arial",20))
        txt_sub.place(x=230,y=294)

        staff_con=Label(staff_Frame,text="Contact NO",font=("times new roman",25,"bold"))
        staff_con.place(x=550,y=190)

        txtcon=Entry(staff_Frame,bd=7,textvariable=self.contact,width=15,font=("Arial",20),relief=GROOVE)
        txtcon.place(x=780,y=190)
        

        staff_sal=Label(staff_Frame,text="Salary",font=("times new roman",25,"bold"))
        staff_sal.place(x=15,y=410)

        txt_con=Entry(staff_Frame,bd=7,textvariable=self.salary,relief=GROOVE,width=15,font=("arial",20))
        txt_con.place(x=230,y=410)

        staff_last=Label(staff_Frame,text="Last Name",font=("times new roman",25,"bold"))
        staff_last.place(x=550,y=80)

        txt_last=Entry(staff_Frame,bd=7,textvariable=self.last_name,width=15,relief=GROOVE,font=("arial",20))
        txt_last.place(x=780,y=80)

        staff_gen=Label(staff_Frame,text="Gender",font=("times new roman",25,"bold"))
        staff_gen.place(x=550,y=290)
        gencombo=ttk.Combobox(staff_Frame,width=14,textvariable=self.gender,font=("Arial",20,"bold"),state="readonly")
        gencombo['values']=("Male","Female")
        gencombo.place(x=780,y=290)

        staff_course=Label(staff_Frame,text="Course",font=("times new roman",25,"bold"))
        staff_course.place(x=550,y=410)
        coursecombo=ttk.Combobox(staff_Frame,width=14,textvariable=self.course,font=("Arial",20,"bold"),state="readonly")
        coursecombo['values']=("BA   25000","BCA   30,000","B.Com   50,000","BBA   55,000","BCA   55,000","D.Pharma   75000","MCA    76,000","MBA    79,000","B.Pharma    90,000","BTECH    95,000")
        coursecombo.place(x=780,y=410)

        btn_Frame=Frame(self.root,bd=10,relief=GROOVE)
        btn_Frame.place(x=10,y=665,width=1525,heigh=125)

        btn_save=Button(btn_Frame,text="Save",font=("Arial",27,"bold"),command=self.save_data,bd=6,width=8)
        btn_save.place(x=40,y=10)

        btn_del=Button(btn_Frame,text="Delete",command=self.delete,font=("Arial",27,"bold"),bd=6,width=8)
        btn_del.place(x=440,y=10)

        btn_cl=Button(btn_Frame,text="Clear",font=("Arial",27,"bold"),command=self.clear,bd=6,width=8)
        btn_cl.place(x=850,y=10)

        btn_exit=Button(btn_Frame,command=self.exit,text="Exit",font=("Aial",27,"bold"),bd=6,width=8)
        btn_exit.place(x=1270,y=10)

        file_Frame=Frame(self.root,bd=7,relief=GROOVE)
        file_Frame.place(x=1100,y=85,width=420,height=550)

        ftitle=Label(file_Frame,text="All files",font=("arial",20,"bold"),bd=6,relief=GROOVE)
        ftitle.place(x=5,y=5,width=397,height=50)

        
        scroll_y=Scrollbar(file_Frame,orient=VERTICAL)
        self.file_list=Listbox(file_Frame,yscrollcommand=scroll_y.set)
        scroll_y.place(x=366,y=60,width=30,height=470)
        scroll_y.config(command=self.file_list.yview)
        self.file_list.place(x=3,y=54,width=359,height=479)
        self.file_list.bind("<ButtonRelease-1>",self.get_data)
        self.show_files1()

    def save_data(self):
        if self.first_name.get()=="":
                messagebox.showerror("Error","First_name must be required..")
        else:
            f=open("files1/"+str(self.first_name.get())+".txt","w")
            f.write(
                    str(self.first_name.get())+","+
                    str(self.qualification.get())+","+
                    str(self.subject.get())+","+
                    str(self.salary.get())+","+
                    str(self.last_name.get())+","+
                    str(self.contact.get())+","+
                    str(self.gender.get())+","+
                    str(self.course.get())
                    )
            f.close()
            messagebox.showinfo("Sucess","Record has been saved..")
            self.show_files1()

    def show_files1(self):
        files1=os.listdir("files1/")
        self.file_list.delete(0,END)
        if len(files1)>0:
            
            for i in files1:
                self.file_list.insert(END,i)


    def get_data(self,ev):
        get_cursor=self.file_list.curselection()
        #print(self.file_list.get(get_cursor)
        f1=open("files1/"+self.file_list.get(get_cursor))
        value=[]
        for f in f1:
            value=f.split(",")


        self.first_name.set(value[0])
        self.qualification.set(value[1])
        self.subject.set(value[2])
        self.salary.set(value[3])
        self.last_name.set(value[4])
        self.contact.set(value[5])
        self.gender.set(value[6])
        self.course.set(value[7])


    def clear(self):
        self.first_name.set("")
        self.qualification.set("")
        self.subject.set("")
        self.salary.set("")
        self.last_name.set("")
        self.contact.set("")
        self.gender.set("")
        self.course.set("")



    def delete(self):
        present="no"
        if self.first_name.get()=="":
            messagebox.showerror("Error","First name must be required..")

        else:
            f=os.listdir("files1/")
            if len(f)>0:
                for i in f:
                    if i.split(".")[0]==self.first_name.get():
                        present="yes"

                if present=="yes":
                    ask=messagebox.askyesno("Delete","Do you really want to delete..")
                    if ask>0:
                        os.remove("files1/"+self.first_name.get()+".txt")
                        messagebox.showinfo("Success","Delete sucessfully")
                        self.show_files1()
                else:
                    messagebox.showerror("error","file not found")


    def exit(self):
        ask=messagebox.askyesno("exit","Do you really want to exit..")
        if ask>0:
            self.root.destroy()
            Panel.panel()
            
