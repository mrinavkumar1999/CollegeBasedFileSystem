from tkinter import *
import login

class Home:
	def __init__(self,root):
		self.root=root
		self.root.title("College Based File Record System")
		self.root.geometry("1540x790+0+0")

		title=Label(self.root,text="Home",font=("times new roman",40,"bold"),bg="skyblue",fg="black",bd=10,relief=GROOVE)
		title.place(x=0,y=0,relwidth=1)
                
		f1=Frame(bd=9,relief=GROOVE,bg="skyblue")
		f1.place(x=370,y=150,width=800,height=450)
		un=Label(f1,text="COLLEGE BASED FILE RECORD SYSTEM",font=("Arial",26),bg="skyblue")
		un.place(x=60,y=50)
		b1=Button(f1,text="START",font=("Arial",25),bd=6,width=8,command=self.log_in)
		b1.place(x=340,y=210,height=80,width=150)

	def log_in(self):
		self.root.destroy()
		login.Login()

       
root=Tk()	
obj=Home(root)
root.mainloop()
from tkinter import *
import login

class Home:
	def __init__(self,root):
		self.root=root
		self.root.title("College Based File Record System")
		self.root.geometry("1540x790+0+0")

		title=Label(self.root,text="Home",font=("times new roman",40,"bold"),bg="skyblue",fg="black",bd=10,relief=GROOVE)
		title.place(x=0,y=0,relwidth=1)
                
		f1=Frame(bd=9,relief=GROOVE,bg="skyblue")
		f1.place(x=370,y=150,width=800,height=450)
		un=Label(f1,text="COLLEGE BASED FILE RECORD SYSTEM",font=("Arial",26),bg="skyblue")
		un.place(x=60,y=50)
		b1=Button(f1,text="START",font=("Arial",25),bd=6,width=8,command=self.log_in)
		b1.place(x=340,y=210,height=80,width=150)

	def log_in(self):
		self.root.destroy()
		login.Login()

       
root=Tk()	
obj=Home(root)
root.mainloop()
   
