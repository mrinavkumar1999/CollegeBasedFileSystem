from tkinter import*
import studentdetail
import staffdetail
import examdetail
import fee

class panel:
    def __init__(self):
        self.root=Tk()
        self.root.title("college Based File Record System")
        self.root.geometry("1540x790+0+0")

        title=Label(self.root,text="PANEL",font=("times new roman",40,"bold"),bg="Skyblue",fg="Black",bd=7,relief=GROOVE)
        title.place(x=0,y=0,relwidth=1)
        
        f1=Frame(self.root,bg="white",bd=8,relief=GROOVE)
        f1.place(x=490,y=170,width=690,height=560)
        
        un=Label(f1,text="Student Record",font=("Arial",25),bg="white",
        fg="black")
        un.place(x=50,y=50)
        
        b1=Button(f1,text="CLICK",font=("Arial",20),bd=6,width=7,
        command=self.student_record)
        b1.place(x=390,y=40)
        
        u2=Label(f1,text="Staff Record",font=("Arial",25),bg="white",fg="black")
        u2.place(x=50,y=150)
        
        b2=Button(f1,text="CLICK",font=("Arial",20),bd=6,width=7,
        command = self.staff_details)
        b2.place(x=390,y=150)

        u4=Label(f1,text="Exam Record",font=("Arial",25),bg="white",fg="black")
        u4.place(x=50,y=250)

        b3=Button(f1,text="CLICK",font=("Arial",20),bd=6,width=7,
        command = self.exam_details)
        b3.place(x=390,y=250)

        u5=Label(f1,text="Fee Record",font=("Arial",25),bg="white",fg="black")
        u5.place(x=50,y=350)

        b4=Button(f1,text="CLICk",font=("Arial",20),bd=6,width=7,
        command = self.fee_details)
        b4.place(x=390,y=350)

    def student_record(self):
        self.root.destroy()
        studentdetail.Studentdetail()

    def staff_details(self):
        self.root.destroy()
        staffdetail.Staffdetail()

    def exam_details(self):
        self.root.destroy()
        examdetail.Examdetail()

    def fee_details(self):
        self.root.destroy()
        fee.Feedetails()



