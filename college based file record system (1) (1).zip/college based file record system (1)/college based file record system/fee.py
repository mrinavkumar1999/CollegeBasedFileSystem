from tkinter import*
from tkinter import ttk,messagebox
import os
import Panel

class Feedetails:
    def __init__(self):
        self.root=Tk()
        self.root.title("College Based File Record System")
        self.root.geometry("1540x790+0+0")

        
        title=Label(self.root,text="FEE RECORD",font=("times new roman",40,"bold"),bd=7,bg="skyblue",fg="black",relief=GROOVE)
        title.place(x=0,y=0,relwidth=1)

        Fee_Frame=Frame(self.root,bd=7,relief=GROOVE)
        Fee_Frame.place(x=10,y=85,width=1068,height=550)

        Fee_title=Label(Fee_Frame,text="Fee Details",font=("times new roman",30,"bold"))
        Fee_title.place(x=350,y=5)


        #*****All Variables*******
        self.admission=StringVar()
        self.name=StringVar()
        self.std_id=StringVar()
        self.course=StringVar()
        self.semester=StringVar()
        self.payment=StringVar()
        self.paid=StringVar()
        self.due=StringVar()

        Fee_admission=Label(Fee_Frame,text="Admission No.",font=("times new roman",25,"bold"))
        Fee_admission.place(x=15,y=80)

        txt_admission=Entry(Fee_Frame,textvariable=self.admission,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_admission.place(x=230,y=80)

        Fee_name=Label(Fee_Frame,text="Name",font=("times new roman",25,"bold"))
        Fee_name.place(x=15,y=190)

        txt_name=Entry(Fee_Frame,textvariabl=self.name,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_name.place(x=230,y=190)

        Fee_std_id=Label(Fee_Frame,text="Student Id",font=("times new roman",25,"bold"))
        Fee_std_id.place(x=15,y=294)

        txt_std_id=Entry(Fee_Frame,textvariable=self.std_id,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_std_id.place(x=230,y=294)

        Fee_course=Label(Fee_Frame,text="Course",font=("times new roman",25,"bold"))
        Fee_course.place(x=15,y=410)

        coursecombo=ttk.Combobox(Fee_Frame,textvariable=self.course,width=14,font=("Ariel",20,"bold"),state="readonly")
        coursecombo['values']=("BA                                                      25,000",
                               "BSc                                                     30,000",
                               "B.Com                                                50,000",
                               "BBA                                                     55,000",
                               "BCA                                                     55,000",
                               "D.pharma                                           75,000",
                               "MCA                                                   76,000",
                               "MBA                                                   79,000",
                               "B.PHARMA                                        90,000",
                               "BTECH                                               95,000")
        coursecombo.place(x=230,y=410)

        Fee_sem=Label(Fee_Frame,text="Semester",font=("times nwe roman",25,"bold"))
        Fee_sem.place(x=550,y=80)

        txt_sem=Entry(Fee_Frame,textvariable=self.semester,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_sem.place(x=780,y=80)

        Fee_mode=Label(Fee_Frame,text="Payment Mode",font=("times new roman",25,"bold"))
        Fee_mode.place(x=550,y=190)

        modecombo=ttk.Combobox(Fee_Frame,textvariable=self.payment,width=14,font=("Arial",20,"bold"),state="readonly")
        modecombo['values']=("Checque","Cash")
        modecombo.place(x=780,y=190)

        Fee_paid=Label(Fee_Frame,text="Paid Amount",font=("times nwe roman",25,"bold"))
        Fee_paid.place(x=550,y=290)

        txt_paid=Entry(Fee_Frame,textvariable=self.paid,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_paid.place(x=780,y=290)

        Fee_due=Label(Fee_Frame,text="Due Amount",font=("times new roman",25,"bold"))
        Fee_due.place(x=550,y=410)

        txt_due=Entry(Fee_Frame,textvariable=self.due,bd=7,relief=GROOVE,width=15,font=("Arial",20))
        txt_due.place(x=780,y=410)

        btn_Frame=Frame(self.root,bd=10,relief=GROOVE)
        btn_Frame.place(x=10,y=665,width=1525,heigh=125)

        btn_save=Button(btn_Frame,text="Save",font=("Arial",27,"bold"),command=self.save_data,bd=6,width=8)
        btn_save.place(x=40,y=10)

        btn_del=Button(btn_Frame,text="Delete",font=("Arial",27,"bold"),command=self.delete,bd=6,width=8)
        btn_del.place(x=440,y=10)

        btn_cl=Button(btn_Frame,text="Clear",font=("Arial",27,"bold"),command=self.clear,bd=6,width=8)
        btn_cl.place(x=850,y=10)

        
        btn_exit=Button(btn_Frame,text="Exit",font=("Aial",27,"bold"),command=self.exit,bd=6,width=8)
        btn_exit.place(x=1270,y=10)

        file_Frame=Frame(self.root,bd=7,relief=GROOVE)
        file_Frame.place(x=1100,y=85,width=420,height=550)

        ftitle=Label(file_Frame,text="All files",font=("arial",20,"bold"),bd=6,relief=GROOVE)
        ftitle.place(x=5,y=5,width=397,height=50)


        scroll_y=Scrollbar(file_Frame,orient=VERTICAL)
        self.file_list=Listbox(file_Frame,yscrollcommand=scroll_y.set)
        scroll_y.place(x=366,y=60,width=30,height=470)
        scroll_y.config(command=self.file_list.yview)
        self.file_list.place(x=3,y=54,width=359,height=479)
        self.file_list.bind("<ButtonRelease-1>",self.get_data)
        self.show_files3()


    def save_data(self):
        if self.admission.get()=="":
            messagebox.showerror("Error","Admission no. must be required..")

        else:
            f=open("files1/"+str(self.admission.get())+".txt","w")
            f.write(
                    str(self.admission.get())+","+
                    str(self.name.get())+","+
                    str(self.std_id.get())+","+
                    str(self.course.get())+","+
                    str(self.semester.get())+","+
                    str(self.payment.get())+","+
                    str(self.paid.get())+","+
                    str(self.due.get())
                    )
            f.close()
            messagebox.showinfo("Success","Record has been saved..")
            self.show_files3()

           


    def show_files3(self):
        files3=os.listdir("files3/")
        self.file_list.delete(0,END)
        if len(files3)>0:

            for i in files3:
                self.file_list.insert(END,i)
       

    def get_data(self,ev):
        get_cursor=self.file_list.curselection()
        #print(self.file_list.get(get_cursor)
        f1=open("file3/"+self.file_list.get(get_cursor))
        value=[]
        for f in f1:
            value=f.split(",")

        self.admission.set(value[0])
        self.name.set(value[1])
        self.std_id.set(value[2])
        self.course.set(value[3])
        self.semester.set(value[4])
        self.payment.set(value[5])
        self.paid.set(value[6])
        self.due.set(value[7])


        
    def delete(self):
        present="no"
        if self.admission.get()=="":
            messagebox.showerror("Error","Admission no must be required..")
            

        else:
            f=os.listdir("files3/")
            if len(f)>0:
                for i in f:
                    if i.split(".")[0]==self.admission.get():
                        present="yes"
                        
                if present=="yes":
                    ask=messagebox.askyesno("Delete","Do you want to delete..")
                    if ask>0:
                        os.remove("files3/"+self.admission.get()+".txt")
                        messagebox.showinfo("Success","Delete sucessfully")
                        self.show_files3()

                    else:
                         messagebox.showerror("error","file not found")
                            

    def clear(self):
        self.admission.set("")
        self.name.set("")
        self.std_id.set("")
        self.course.set("")
        self.semester.set("")
        self.payment.set("")
        self.paid.set("")
        self.due.set("")

        

        

    def exit(self):
        ask=messagebox.askyesno("exit","do you really want to exit..")
        if ask>0:
            self.root.destroy()
            Panel.panel()

        
        
                        
        

        
