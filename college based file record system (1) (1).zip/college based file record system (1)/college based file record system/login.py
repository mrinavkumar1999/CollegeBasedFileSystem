from tkinter import*
from tkinter import messagebox
import Panel

class Login:
        def __init__(self):
                
            self.root=Tk()
            self.root.title("College Based File Record System")
            self.root.geometry("1540x790+0+0")
            
            title=Label(self.root,text="LOGIN SYSTEM",font=("times new roman",40,"bold"),bg="skyblue",fg="black",bd=10,relief=GROOVE)
            title.place(x=0,y=0,relwidth=1)
            
            f1=Frame(self.root,bd=10,relief=GROOVE)
            f1.place(x=490,y=270,width=580,height=350)
            self.user=StringVar()
            self.password=StringVar()
            
            lblusername=Label(f1,text="Username :",font=("times new roman",25,"bold"))
            lblusername.place(x=80,y=40)
            
            txtuser=Entry(f1,bd=4,relief=GROOVE,textvariable=self.user,font=("Arial",18))
            txtuser.place(x=260,y=50)
            
            lblpass=Label(f1,text="Password :",font=("times new roman",25,"bold"))
            lblpass.place(x=80,y=130)
            
            txtpass=Entry(f1,bd=4,relief=GROOVE,show="*",textvariable=self.password,font=("Arial",18))
            txtpass.place(x=260,y=130)
            
            btnlog=Button(f1,text="Login",bd=6,width=7,command=self.logfun,font=("Arial 20 bold"))
            btnlog.place(x=30,y=230)
            
            btnreset=Button(f1,text="Reset",bd=6,width=7,command=self.reset,font=("Arial 20 bold"))
            btnreset.place(x=200,y=230)
            
            btnexit=Button(f1,text="Exit",font=("Arial 20 bold"),bd=6,width=7,command=self.exitfun)
            btnexit.place(x=380,y=230)
            
            
        def logfun(self):
                if self.user.get()=="Admin" and self.password.get()=="12345":
                        self.root.destroy()
                        Panel.panel()            
                else:
                        messagebox.showerror("Error","invalid username or password")
        def reset(self):
                self.user.set("")
                self.password.set("")
        def exitfun(self):
                option=messagebox.askyesno("Exit","Do you really want to exit?")
                if option>0:
                        self.root.destroy()
                else:
                        return
                


